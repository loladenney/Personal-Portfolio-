package assignment1;

public class Worker extends Unit{

    private int jobsPreformed;

    public Worker(Tile tile, double hp, String faction){
        super(tile, hp, 2, faction);
        this.jobsPreformed = 0;
    }

    @Override
    public void takeAction(Tile tile) {
        if ((this.getPosition() == tile) && !tile.isImproved()){
            this.getPosition().buildImprovement();
            if (this.jobsPreformed == 9){
                this.getPosition().removeUnit(this);
            }
            this.jobsPreformed ++;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Worker) {
            if (super.equals(obj)) {
                return this.jobsPreformed == ((Worker) obj).jobsPreformed;
            }
        }

        return false;
    }
}
