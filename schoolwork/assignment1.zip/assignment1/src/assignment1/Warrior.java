package assignment1;

public class Warrior extends MilitaryUnit {
    public Warrior(Tile tile, double hp, String faction){
        super(tile, hp, 1, faction, 20.0, 1, 25);

    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Warrior) {
            Warrior obj2 = (Warrior) obj;
            if ((this.getPosition() == obj2.getPosition()) && (obj2.getFaction().equals(this.getFaction()))) {
                //compare hp (double)
                return (Math.pow((this.getHP() - obj2.getHP()), 2) < 0.001);
            }
        }
        return false;
    }
}
