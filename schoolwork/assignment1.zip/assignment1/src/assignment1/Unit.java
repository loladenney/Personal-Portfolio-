package assignment1;

public abstract class Unit {
    private Tile tile;
    private double hp;
    private int range;
    private String faction;

    public Unit(Tile tile, double hp, int range, String faction){
        this.tile = tile;
        this.hp = hp;
        this.range = range;
        this.faction = faction;
        //does 'this' work???,　and does this if statement actually add the instance to the list?
        if (! this.tile.addUnit(this))
            throw new IllegalArgumentException();

    }
        // doesn't actually return an integer array, but returns a Tile object.
    //shouldnt i not return this tile object because it contains the mutable ListOfUnits?????,
    //like why would i make the tile private if i can access it from here anyways??
    public final Tile getPosition(){
        return this.tile;
    }

    public final double getHP(){
        return this.hp;
    }

    public final String getFaction(){
        return this.faction;
    }


    // fix for null input

    public boolean moveTo(Tile finalTile){
        // check for null Tile
        if (finalTile == null) return false;

        //not in range
        if (this.range < Tile.getDistance(this.tile, finalTile)){
            return false;
        }

        //this should check if unit is allowed to be stationed on the tile
        if (finalTile.addUnit(this)) {

            //removes unit from tile
            this.tile.removeUnit(this);

            //updates unit's tile
            this.tile = finalTile;

            return true;
        }

        return false;
    }

    public void receiveDamage(double damage){
        //if damage is negative return
        if (damage < 0)
            return;

        //if stationed on a city reduce damage taken by 10% before applying
        if (this.tile.isCity())
            damage *= 0.9;

        //take damage
        this.hp -= damage;

        //if resulting hp is <=0 unit dies, remove from tile
        if (this.hp <= 0){
            this.tile.removeUnit(this);
        }

    }

    public abstract void takeAction(Tile tile);

    //test this one extensively please
    //issues with downcasting the object to a unit, i want to down cast it to the relevant subclass of a unit.
    public boolean equals(Object obj){

        if (obj instanceof Unit) {
            Unit obj2 = (Unit) obj;
            if ((this.tile == obj2.tile) && (obj2.faction.equals(this.faction))) {
                //compare hp (double)
                return (Math.pow((this.hp - obj2.hp), 2) < 0.001);
            }
        }
        return false;

    }

}
