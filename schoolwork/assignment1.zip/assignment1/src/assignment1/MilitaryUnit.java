package assignment1;

public abstract class MilitaryUnit extends Unit{
    private double attackDamage;
    private int attackRange;
    private int armour;

    public MilitaryUnit(Tile tile, double hp, int range, String faction, double attackDamage, int attackRange, int armour){
        super(tile, hp, range, faction);
        this.attackDamage = attackDamage;
        this.attackRange = attackRange;
        this.armour = armour;

    }

    public void takeAction(Tile target) {
        if (Tile.getDistance(target, this.getPosition()) > this.attackRange){
            return;
        }

        if (target.selectWeakEnemy(this.getFaction()) == null){
            return;
        }

        Unit enemy = target.selectWeakEnemy(this.getFaction());

        double damage = this.attackDamage;

        //NOT TARGET IMPROVED I WANT TO CHECK SELF TILE IMPROVED OR NOT
        if (this.getPosition().isImproved()){
            damage *= 1.05;
        }

        enemy.receiveDamage(damage);
    }

    public void receiveDamage(double damage) {
        damage = (damage*(100.0/(100.0+this.armour)));
        super.receiveDamage(damage);
    }
}
