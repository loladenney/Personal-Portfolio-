package assignment1;

public class Settler extends Unit {

    public Settler(Tile tile, double hp, String faction){
        super(tile, hp,2, faction);

    }

    //does == work here?
    @Override
    public void takeAction(Tile tile) {
        if ((this.getPosition().equals(tile)) && !tile.isCity()){
            this.getPosition().buildCity();
            this.getPosition().removeUnit(this);
        }
    }


    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Settler)
            return super.equals(obj);
        return false;
    }
}
