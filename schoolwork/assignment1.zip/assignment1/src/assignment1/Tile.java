package assignment1;

public class Tile {
    private int xcoord;
    private int ycoord;
    private boolean city;
    private boolean improvement;
    private ListOfUnits unitsOnTile;

    public Tile(int xcoord ,int ycoord){
        this.xcoord = xcoord;
        this.ycoord = ycoord;
        this.city = false;
        this.improvement = false;
        this.unitsOnTile = new ListOfUnits();
    }

    //make sure for get and set methods the type is immutable or its a copy
    public int getX(){
        return this.xcoord;
    }

    public int getY(){
        return this.ycoord;
    }

    public boolean isCity(){
        return this.city;
    }

    public boolean isImproved(){
        return this.improvement;
    }

    public void buildCity(){
        this.city = true;
    }

    //why is build improvement not being updated by this?
    public void buildImprovement(){
        this.improvement = true;
    }


    //can change this to use getArmy method, but it works so i might just leave it
    public boolean addUnit(Unit unit){
        if (unit instanceof Warrior || unit instanceof Archer){
            String faction = unit.getFaction();
            for ( Unit x : unitsOnTile.getArmy()) {
                if ( ! x.getFaction().equals(faction)) {
                    return false;
                }
            }
        }
        //test this a lot idk if it works
        if (unit != null) {
            unitsOnTile.addUnit(unit);
            return true;
        }
        return false;
    }

    //if this is failing check removeUnit() in ListOfUnit
    public boolean removeUnit(Unit x){

        return unitsOnTile.removeUnit(x);
    }

    //return null error???
    public Unit selectWeakEnemy(String faction){
        double lowestHP = Double.POSITIVE_INFINITY;
        Unit weakestEnemy = null;

        for ( Unit enemy : unitsOnTile.getList()) {

            if ( !( enemy.getFaction().equals(faction))){
                if (enemy.getHP()< lowestHP) {
                    lowestHP = enemy.getHP();
                    weakestEnemy = enemy;
                }
            }
        }

        return weakestEnemy;

    }

    public static double getDistance(Tile tile1, Tile tile2){
        int x1 = tile1.getX();
        int y1 = tile1.getY();
        int x2 = tile2.getX();
        int y2 = tile2.getY();
        return Math.sqrt(Math.pow((x1-x2),2)+Math.pow((y1-y2),2));
    }




}
