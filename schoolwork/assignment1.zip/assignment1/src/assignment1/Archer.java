package assignment1;

public class Archer extends MilitaryUnit {
    private int arrows;

    public Archer(Tile tile, double hp, String faction){
        super(tile, hp, 2, faction, 15.0, 2, 0);

        this.arrows = 5;

    }

    @Override
    public void takeAction(Tile target) {
        if (this.arrows == 0){
            this.arrows = 5;
            return;
        }
        this.arrows --;
        super.takeAction(target);

    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Archer) {
            if (super.equals(obj)) {
                return this.arrows == ((Archer) obj).arrows;
            }
        }
        return false;
    }
}
