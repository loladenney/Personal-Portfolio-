package assignment1;

public class ListOfUnits {
    private Unit[] units;
    private int size;

    public ListOfUnits(){
        this.units = new Unit[0];
        this.size = 0;

    }

    public int getSize(){
        return this.size;
    }

    //please check edge case of empty array and check for null elements????
    public Unit[] getList(){

        return this.units.clone();
    }

    //is returning an object the same as returning its reference
    public Unit getUnit(int index){
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException();
        return this.units[index];

    }
    //creating private helper method for increasing size of the array
    public void addUnit(Unit x ){
        if (x != null) {
            incrementListLength();
            //is this -1 correct?????
            this.units[this.size - 1] = x;
        }

    }

    //kind of slow, come back and change everything to arraylists???
    private void incrementListLength(){
        Unit[] newUnits = new Unit[this.size+1];
        for( int i =0; i <this.size; i++){
            newUnits[i] = units[i];
        }
        this.units = newUnits;
        this.size ++;
    }

    //check that equals takes faction etc. in to account
    public int indexOf(Unit x){
        for (int i = 0; i < this.size; i++) {
            if (this.units[i].equals(x)) {
                return i;
            }
        }

        return -1;

    }
    //check that equals takes faction in to account
    // also remove to index from the list as well?? creating a whole new list??
    //check all off by 1 errors
    public boolean removeUnit(Unit x){
        int xIndex = indexOf(x);
        if (xIndex == -1 ){
            return false;
        }

        Unit[] newUnits = new Unit[this.size-1];
        for(int i = 0; i<xIndex; i++){
            newUnits[i] = units[i];
        }
        //maybe  an issues overwriting the variable??
        for(int i = xIndex; i<this.size-1; i++){
            newUnits[i] = units[i+1];
        }

        this.units = newUnits;
        --this.size;
        return true;
    }
    //might be an issue with i<this.size in all for loops. check if it should be i<=this.size
    public MilitaryUnit[] getArmy(){
        int milSize = 0;
        for (Unit x: this.units){
            if (x instanceof MilitaryUnit){
                milSize ++;
            }
        }

        MilitaryUnit[] militaryUnits = new MilitaryUnit[milSize];
        int milIndex = 0;

        for(int i = 0; i<this.size; i++) {
            if (units[i] instanceof MilitaryUnit) {
                militaryUnits[milIndex] = (MilitaryUnit) units[i];
                milIndex ++;
            }
            //milIndex was already incremented so this works as a check, this is a time saver
            if (milIndex == milSize) {
                return militaryUnits;
            }
        }

        return militaryUnits;
    }

}
