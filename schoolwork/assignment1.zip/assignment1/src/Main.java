import assignment1.*;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");
        Tile tile = new Tile(1,1);
        Tile tile2 = new Tile(1,2);
        tile.buildImprovement();

        Worker worker = new Worker(tile2, 5, "Four");

        Warrior warrior = new Warrior(tile, 3, "Test");
        warrior.takeAction(tile2);
    }
}