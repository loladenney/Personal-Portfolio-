package assignment2;

import assignment2.food.*;

import java.awt.*;

public class Tester {

    public static void main(String[] args) {
        Position startingPoint = new Position(3, 2);
        Caterpillar gus = new Caterpillar(startingPoint, GameColors.GREEN, 20);

        System.out.println("1) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);

        gus.move(new Position(3,1));
        gus.eat(new Fruit(GameColors.RED));
        gus.move(new Position(2,1));
        gus.move(new Position(1,1));
        gus.eat(new Fruit(GameColors.YELLOW));

        System.out.println("\n2) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);

        gus.move(new Position(1,2));
        gus.eat(new IceCream());

        System.out.println("\n3) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);

        gus.move(new Position(3,1));
        gus.move(new Position(3,2));
        gus.eat(new Fruit(GameColors.ORANGE));

        System.out.println("\n4) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);

        gus.move(new Position(2,2));
        gus.eat(new SwissCheese());

        System.out.println("\n5) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);

        gus.move(new Position(2, 3));
        gus.eat(new Cake(4));

        System.out.println("\n6) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);

        gus.move(new Position(2, 4));
        gus.eat(new Cake(10));


        System.out.println("\n9) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);
        System.out.println(" turnsNeededToDigest: " + gus.turnsNeededToDigest);

        gus.move(new Position(2, 5));
        gus.move(new Position(2, 6));
        gus.move(new Position(3, 6));
        gus.move(new Position(4, 6));
        gus.move(new Position(5, 6));
        gus.move(new Position(6, 6));
        gus.move(new Position(7, 6));
        gus.move(new Position(8, 6));


        System.out.println("testing using energy on subsequent turns");
        System.out.println("\n10) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);
        System.out.println(" turnsNeededToDigest: " + gus.turnsNeededToDigest);

    /*
        System.out.println(GameColors.colorToString(gus.getSegmentColor(gus.getHeadPosition())));
        System.out.println("\n7) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);

        gus.move(new Position(3, 4));

        System.out.println("\n8) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);

        gus.move(new Position(4, 4));
        gus.eat(new Fruit(GameColors.BLUE));

        System.out.println("\n8.5) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);
        System.out.println(" turnsNeededToDigest: " + gus.turnsNeededToDigest);

        gus.move(new Position(5, 4));
        gus.eat(new Cake(5));


        System.out.println("\n9) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);
        System.out.println(" turnsNeededToDigest: " + gus.turnsNeededToDigest);

        gus.eat(new SwissCheese());

        System.out.println("swiss cheese");
        System.out.println("\n10) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);

        gus.eat(new IceCream());

        System.out.println("ice cream, clears stack");
        System.out.println("\n11) Gus: " + gus);
        System.out.println("Stack of previously occupied positions: " + gus.positionsPreviouslyOccupied);
        */
    }
}
