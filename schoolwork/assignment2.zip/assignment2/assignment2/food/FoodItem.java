package assignment2.food;

import assignment2.Caterpillar;

public abstract class FoodItem {

	public abstract void accept(Caterpillar c);
	
}
