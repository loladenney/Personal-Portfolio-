package assignment2;

import java.awt.Color;
import java.util.Random;
import java.util.Stack;

import assignment2.food.*;


public class Caterpillar {
    // All the fields have been declared public for testing purposes
    public Segment head;
    public Segment tail;
    public int length;
    public EvolutionStage stage;

    public Stack<Position> positionsPreviouslyOccupied;
    public int goal;
    public int turnsNeededToDigest;


    public static Random randNumGenerator = new Random(1);


    // Creates a Caterpillar with one Segment. It is up to students to decide how to implement this.
    public Caterpillar(Position p, Color c, int goal){
        this.head = new Segment(p,c);
        this.tail = this.head;
        this.goal = goal;
        this.length = 1;
        this.stage = EvolutionStage.FEEDING_STAGE;
        this.turnsNeededToDigest = 0;
        this.positionsPreviouslyOccupied = new Stack<Position>();
    }


    public EvolutionStage getEvolutionStage() {
        return this.stage;
    }

    public Position getHeadPosition() {
        return this.head.position;
    }

    public int getLength() {
        return this.length;
    }


    // returns the color of the segment in position p. Returns null if such segment does not exist
    public Color getSegmentColor(Position p) {
        Color color = null;
        Segment curr = this.head;
        for(int i=0; i<this.length; i++, curr = curr.next){
            if (curr.position.equals(p)) {
                color = curr.color;
                break;
            }
        }
        return color;
    }


    // shift all Segments to the previous Position while maintaining the old color
    public void move(Position p) {
        if (Position.getDistance(getHeadPosition(),p) != 1){
            throw new IllegalArgumentException("position out of reach");
        }

        //check for collision
        if (collisionDetect(p)){
            this.stage = EvolutionStage.ENTANGLED;
            return;
        }

        //move (please test a lot)
        positionsPreviouslyOccupied.add(tail.position);
        Position currPos = getHeadPosition();
        head.position = p;
        Position nextPos = currPos;
        Segment curr = head.next;

        while (curr != null){
            currPos = curr.position;
            curr.position = nextPos;
            curr = curr.next;
            nextPos = currPos;
        }

        //still digesting a cake case
        if (getEvolutionStage() == EvolutionStage.GROWING_STAGE){
            //add segment of random color
            addSegmentRandColor();
            turnsNeededToDigest--;
            //butterfly check
            if (length == goal){
                this.stage = EvolutionStage.BUTTERFLY;
                return;
            }
            if(turnsNeededToDigest==0)
                this.stage = EvolutionStage.FEEDING_STAGE;
        }
    }

    //helper function for move
    private boolean collisionDetect(Position p){
        Segment curr = this.head;

        while (curr != null) { //does this produce a null pointer exception???
            if (curr.position.equals(p)) {
                return true;
            }
            curr = curr.next;
        }
        return false;
    }


    // a segment of the fruit's color is added at the end
    public void eat(Fruit f) {
        Color color = f.getColor();
        tail.next = new Segment(positionsPreviouslyOccupied.pop(), color);
        tail = tail.next;
        this.length ++;

        if (this.length >= this.goal)
            this.stage = EvolutionStage.BUTTERFLY;
    }

    // the caterpillar moves one step backwards because of sourness
    public void eat(Pickle p) {
        Segment curr = this.head;

        //from head to tail-1
        while (curr != this.tail){
            curr.position = curr.next.position;
            curr = curr.next;
        }
        //for tail
        tail.position = positionsPreviouslyOccupied.pop();
    }


    // all the caterpillar's colors shuffles around
    public void eat(Lollipop lolly) {
        //array of colors
        Color[] colors = getColorArray();

        for (int i = this.length-1 ; i>=0 ; i--){
            int j = randNumGenerator.nextInt(i+1);
            Color temp = colors[j];
            colors[j] = colors[i];
            colors[i] = temp;
        }

        Segment curr = head;
        for (int i =0; i<this.length; i++, curr = curr.next){
            curr.color = colors[i];
        }

    }

    //helper method
    private Color[] getColorArray(){
        Color[] colors = new Color[this.length];
        Segment curr = head;
        for (int i =0; i<this.length; i++, curr=curr.next){
            colors[i] = getSegmentColor(curr.position);
        }
        return colors;
    }

    // brain freeze!!
    // It reverses and its (new) head turns blue
    public void eat(IceCream gelato) {
        //empty stack
        positionsPreviouslyOccupied.clear();

        //flip
        Segment curr = head;
        Segment next = null;
        Segment prev = null;
        while (curr!=null){
            next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }
        Segment temp = this.head;
        this.head = this.tail;
        this.tail = temp;

        //turn new head blue
        this.head.color = GameColors.BLUE;
    }

    // the caterpillar embodies a slide of Swiss cheese loosing half of its segments.
    public void eat(SwissCheese cheese) {
        Segment curr = this.head;

        //reassign colors
        Color[] colors = getColorArray();
        for (int i =0; i<this.length; i+=2) {
            curr.color = colors[i];
            if (length != i+1 && length!= i+2) {//could have been written more clearly
                curr = curr.next;
            }
        }

        //here, curr should be the new tail
        this.tail = curr;

        //de-link second half and add the positions to stack
        curr = curr.next;
        Stack<Position> reversePosition = new Stack<>();
        while (curr != null){
            Segment next = curr.next;
            reversePosition.add(curr.position);
            curr.next = null;
            curr = next;
        }
        while (!reversePosition.empty()){
            positionsPreviouslyOccupied.add(reversePosition.pop());
        }


        //set length to length/2 rounded up (could rewrite this better)
        if ( getLength() % 2 == 1){
            length = (getLength()/2) +1;
        }
        else {
            length = getLength() / 2;
        }

        //set tail.next to null
        tail.next = null;
    }


    public void eat(Cake cake) {
        this.stage = EvolutionStage.GROWING_STAGE;
        int energy = cake.getEnergyProvided();

        while (energy > 0) {
            //break out of building loop is there are no positions to occupy
            if (positionsPreviouslyOccupied.empty()) break;

            //caterpillar overlap catch
            Position pos = positionsPreviouslyOccupied.peek();
            Segment curr = this.head;

            while (curr != null) { //does this produce a null pointer exception???
                if (curr.position.equals(pos)) {
                    this.turnsNeededToDigest = energy;
                    this.stage = EvolutionStage.GROWING_STAGE;
                    return;
                }
                curr = curr.next;
            }

            //add a segment of random color to tail
            addSegmentRandColor();
            energy--;

            //check if goal is reached
            if (length >= goal) {
                this.stage = EvolutionStage.BUTTERFLY;
                return;
            }
        }

        if (energy == 0) {
            this.stage = EvolutionStage.FEEDING_STAGE;
        }
        else {
            this.turnsNeededToDigest = energy;
            this.stage = EvolutionStage.GROWING_STAGE;
        }
    }


    //helper function
    private void addSegmentRandColor(){
        Color randColor = GameColors.SEGMENT_COLORS[randNumGenerator.nextInt(GameColors.SEGMENT_COLORS.length)];
        tail.next = new Segment(positionsPreviouslyOccupied.pop(), randColor);
        tail = tail.next;
        length++;
    }



    // This nested class was declared public for testing purposes
    public class Segment {
        private Position position;
        private Color color;
        private Segment next;

        public Segment(Position p, Color c) {
            this.position = p;
            this.color = c;
        }

    }



    public String toString() {
        Segment s = this.head;
        String gus = "";
        while (s!=null) {
            String coloredPosition = GameColors.colorToANSIColor(s.color) +
                    s.position.toString() + GameColors.colorToANSIColor(Color.WHITE);
            gus = coloredPosition + " " + gus;
            s = s.next;
        }
        return gus;
    }

}